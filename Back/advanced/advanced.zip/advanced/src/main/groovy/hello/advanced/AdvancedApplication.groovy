package hello.advanced

import org.springframework.boot.SpringApplication
import org.springframework.boot.autoconfigure.SpringBootApplication

@SpringBootApplication
class AdvancedApplication {

	static void main(String[] args) {
		SpringApplication.run(AdvancedApplication, args)
	}

}
